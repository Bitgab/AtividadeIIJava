/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consultorio_fuboca.Conexao_ao_banco;
// Importação das classes necessária para conectar ao banco.
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * classe para conectar ao banco MySQL.
 */
public class ConexaoMySQL {
  
    /*
    1 - URL do banco de dados: indica onde está e o nome do banco;
    2 - Usuário do banco;
    3 - Senha do banco nesse caso está vazio. 
    */
    private static final String URL = "jdbc:mysql://localhost:3306/AtividadePontuada2";
    private static final String USER = "root";
    private static final String PASSWORD = "";
   
    // Método para abrir a conexão com o banco de dados.
    public static Connection conectar() {
        
    // O banco tentar conectar usando a URL, usuário e senha.
    try {
        return DriverManager.getConnection(URL, USER, PASSWORD);
     
     // Se der erro na conexão, vai lança uma mensagem de erro.   
    } catch (SQLException e) {
        throw new RuntimeException("Erro na conexão com o banco de dados: " + e.getMessage());
    }
}
}

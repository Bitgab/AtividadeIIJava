/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consultorio_fuboca.controle;

// Importações necessárias para a classe ControleMédico.
import com.mycompany.consultorio_fuboca.dao.MedicoDAO;
import com.mycompany.consultorio_fuboca.modelo.Medico;
import java.util.ArrayList;

/**
 *
 * Classe que faz o controle dos médicos.
 * Também faz ligação entre tela e o banco de dados.
 */
public class ControleMedico {
     // Cria um objeto do DAO para acessar o banco de dados dos médicos.
    private MedicoDAO dao = new MedicoDAO();
    // Método para cadastrar um novo médico
    public void cadastrar(String crm, String especializacao, String primeiroNome, String nomeDoMeio, String ultimoNome) {
        // Cria um novo médico com as informações pedida(CRM, Especialização, Primeiro nome, Nome do Meio, Ultimo Nome)
        Medico m = new Medico(crm, especializacao, primeiroNome, nomeDoMeio, ultimoNome);
        // DAO salvar no banco de dados.
        dao.inserir(m);
    }

    // Método para listar todos os médicos do banco de dados.
    public ArrayList<Medico> listar() {
        // Retorna a lista que o DAO buscar do banco de dados do Médico.
        return dao.listar();
    }
    // método para atualizar os dados de um médico já cadastrado.
    public void atualizar(int idMedico, String crm, String especializacao, String primeiroNome, String nomeDoMeio, String ultimoNome) {
        // Cria um novo médico com  novos dados pedido (ID, CRM, Especialização, Primeiro nome, Nome do Meio, Ultimo Nome)
        Medico m = new Medico(idMedico, crm, especializacao, primeiroNome, nomeDoMeio, ultimoNome);
        // Mandar o DAO atualizar no banco de dados de Médico.
        dao.atualizar(m);
    }
    // método para remover médico pelo Id do banco de dados
    public void remover(int idMedico) {
        // O DAO vai remover do banco de dados do médico.
        dao.remover(idMedico);
    }
}

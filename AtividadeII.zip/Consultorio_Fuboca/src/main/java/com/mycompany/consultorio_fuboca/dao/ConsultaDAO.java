/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consultorio_fuboca.dao;
// Importações necessárias para o funcionamento da classe ConsultaDAO.
import com.mycompany.consultorio_fuboca.Conexao_ao_banco.ConexaoMySQL;
import com.mycompany.consultorio_fuboca.modelo.Consulta;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.util.ArrayList;

/**
 *
 * Classe ConsultaDAO que cuida da tabela no banco.
 * Essa classe faz inserções, busca, atualizações e remoção.
 */
public class ConsultaDAO {
    // Método para inserir ums nova consulta no banco.
    public void inserir(Consulta consulta) throws SQLException {
        // SQL para inserir um consulta.
        String sql = "INSERT INTO consulta (observacao, data, hora, idPaciente, idMedico) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = ConexaoMySQL.conectar(); // -> Conecta ao banco de dados
             PreparedStatement stmt = conn.prepareStatement(sql)) { // -> Prepara o SQL para evitar erro e invasão
            // Preenche os campos da consulta no SQL
            stmt.setString(1, consulta.getObservacao());
            stmt.setDate(2, Date.valueOf(consulta.getData()));
            stmt.setTime(3, Time.valueOf(consulta.getHora()));
            stmt.setInt(4, consulta.getIdPaciente());
            stmt.setInt(5, consulta.getIdMedico());
            // Executa a inserção.
            stmt.executeUpdate();
        } catch (SQLException e) {
            // Se der erro, mostrar no console.
            e.printStackTrace();
        }
    }
    // Método para listar todas as consultas no banco de dados Consulta.
    public ArrayList<Consulta> listar() {
        ArrayList<Consulta> lista = new ArrayList<>();
        String sql = "SELECT * FROM consulta";
        try ( 
                Connection conn = ConexaoMySQL.conectar();// -> Conecta ao banco de dados.
             Statement stmt = conn.createStatement(); // -> Cria uma consulta simples (sem parâmetros)
             ResultSet rs = stmt.executeQuery(sql)) { // -> Executa a busca e recebe o resultado
            // Percorrecada linha do do resultado
            while (rs.next()) {
                Consulta c = new Consulta( // -> Cria uma consulta com os dados da linha(IDConsulta, Observação, Data, Hora, IDPaciente, IDMedico)
                    rs.getInt("idConsulta"),
                    rs.getString("observacao"),
                    rs.getDate("data").toLocalDate(),
                    rs.getTime("hora").toLocalTime(),
                    rs.getInt("idPaciente"),
                    rs.getInt("idMedico")
                );
                // Adiciona na lista.
                lista.add(c);
            }
        } catch (SQLException e) {
            // Se der erro, mostra no console
            e.printStackTrace();
        }
        return lista; // -> retorna a lista de consulta 
    }
    // Método para atualizar uma consulta no banco de dados Consulta.
    public void atualizar(Consulta consulta) {
        String sql = "UPDATE consulta SET observacao = ?, data = ?, hora = ?, idPaciente = ?, idMedico = ? WHERE idConsulta = ?";
        try (Connection conn = ConexaoMySQL.conectar();// -> Conecta ao banco de dados.
             PreparedStatement stmt = conn.prepareStatement(sql)) { // -> Prepara o SQL com Segurança.
            // Preenche os campos novos da consulta.
            stmt.setString(1, consulta.getObservacao());
            stmt.setDate(2, Date.valueOf(consulta.getData()));
            stmt.setTime(3, Time.valueOf(consulta.getHora()));
            stmt.setInt(4, consulta.getIdPaciente());
            stmt.setInt(5, consulta.getIdMedico());
            stmt.setInt(6, consulta.getIdConsulta());
            stmt.executeUpdate(); // -> Executar a atualização 
        } catch (SQLException e) {
            // Se der erro, mostra no console
            e.printStackTrace();
        }
    }
    // Método para remover uma cosulta pelo Id do banco de dados consulta.
    public void remover(int idConsulta) {
        String sql = "DELETE FROM consulta WHERE idConsulta = ?";
        try (Connection conn = ConexaoMySQL.conectar(); // -> Conecta ao Banco de Dados.
             PreparedStatement stmt = conn.prepareStatement(sql)) { // Preparao SQL com segurança
            stmt.setInt(1, idConsulta); // -> Define o ID da consulta a remover
            stmt.executeUpdate(); // -> Executa a remoção.
        } catch (SQLException e) {
            e.printStackTrace(); // -> Se der erro, mostra no console.
        }
    }
}

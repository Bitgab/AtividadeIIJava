/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consultorio_fuboca.dao;
// Importações necessárias para o funcionamento da classe MedicoDAO.
import com.mycompany.consultorio_fuboca.Conexao_ao_banco.ConexaoMySQL;
import com.mycompany.consultorio_fuboca.modelo.Medico;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * Classe que cuida das operações de médico no banco.
 * Essa classe faz inserções, buscar, atualizações e remover médico.
 */
public class MedicoDAO {
    // Método para inserir um novo médico no banco de dados Médico.
    public void inserir(Medico medico) {
        String sql = "INSERT INTO medico (crm, especializacao, primeiroNomeMedico, nomeDoMeioMedico, ultimoNomeMedico) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = ConexaoMySQL.conectar();// -> Conecta ao banco de dados 
             PreparedStatement stmt = conn.prepareStatement(sql)) { // -> Prepara o SQL com segurança
            // -> Preenche os dados do médico no SQL.
            stmt.setString(1, medico.getCrm());
            stmt.setString(2, medico.getEspecializacao());
            stmt.setString(3, medico.getPrimeiroNomeMedico());
            stmt.setString(4, medico.getNomeDoMeioMedico());
            stmt.setString(5, medico.getUltimoNomeMedico());
            stmt.setInt(6,medico.getIdMedico());
            // Executa as atualizações.
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();// -> se der erro, mostra no console
        }
    }
    // Método para listar todos os médicos do banco de dados Médico.
    public ArrayList<Medico> listar() {
        ArrayList<Medico> lista = new ArrayList<>();
        String sql = "SELECT * FROM medico";
        try (Connection conn = ConexaoMySQL.conectar();// -> Conecta ao banco.
             Statement stmt = conn.createStatement();// -> Cria uma consulta simples.
             ResultSet rs = stmt.executeQuery(sql)) {// -> Executa a Consulta.
            // Percorre cada linha do resultado.
            while (rs.next()) {
                // Cria um médico com os dados da linha abaixo.
                Medico m = new Medico(
                    rs.getInt("idMedico"),
                    rs.getString("crm"),
                    rs.getString("especializacao"),
                    rs.getString("primeiroNomeMedico"),
                    rs.getString("nomeDoMeioMedico"),
                    rs.getString("ultimoNomeMedico")
                );
                lista.add(m);// -> Adiciona na lista
            }
        } catch (SQLException e) {
            // Se der erro, mostra no console
            e.printStackTrace();
        }
        return lista;// -> Retorna a lista de médico
    }
    // Método para atualizar os dados de um médico
    public void atualizar(Medico medico) {
        String sql = "UPDATE medico SET crm = ?, especializacao = ?, primeiroNomeMedico = ?, nomeDoMeioMedico = ?, ultimoNomeMedico = ? WHERE idMedico = ?";
        try (Connection conn = ConexaoMySQL.conectar();// -> Conecta ao banco 
             PreparedStatement stmt = conn.prepareStatement(sql)) {// -> Prepara o SQL com segurança
            // Preenche os dados novos de médico
            stmt.setString(1, medico.getCrm());
            stmt.setString(2, medico.getEspecializacao());
            stmt.setString(3, medico.getPrimeiroNomeMedico());
            stmt.setString(4, medico.getNomeDoMeioMedico());
            stmt.setString(5, medico.getUltimoNomeMedico());
            stmt.setInt(6, medico.getIdMedico());
            stmt.executeUpdate();// Executa a atualização 
        } catch (SQLException e) {
            // Se der erro, mostra no console.
            e.printStackTrace();
        }
    }
    // Método para remover um médico pelo ID.
    public void remover(int idMedico) {
        String sql = "DELETE FROM medico WHERE idMedico = ?";
        try (Connection conn = ConexaoMySQL.conectar();// -> Conecta ao banco.
             PreparedStatement stmt = conn.prepareStatement(sql)) { // Prepara o SQL com segurança.
            // Informa o ID do Médico que será apagado.
            stmt.setInt(1, idMedico);
            // Executa a exclusão do médico.
            stmt.executeUpdate();
        } catch (SQLException e) {
            // Se der erro, mostra no console.
            e.printStackTrace();
        }
    }
}

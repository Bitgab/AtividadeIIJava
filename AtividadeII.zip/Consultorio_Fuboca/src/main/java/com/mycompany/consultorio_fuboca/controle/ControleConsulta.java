/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consultorio_fuboca.controle;
// Importações necessárias para o funcionamento da classe ControleConsulta.
import com.mycompany.consultorio_fuboca.dao.ConsultaDAO;
import com.mycompany.consultorio_fuboca.modelo.Consulta;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * Classe que faz o controle das consultas.
 * Também faz ligações entre tela e o banco de dados.
 */
public class ControleConsulta {
    
    // Cria um objeto do DAO para acessar o banco de dados (A ConsultaDAO é responsável por isso)
    private ConsultaDAO dao = new ConsultaDAO();

    // Método para cadastrar uma nova consulta.
    public void cadastrar(String observacao, LocalDate data, LocalTime hora, int idPaciente, int idMedico) throws SQLException {
        // Cria uma consulta com os dados recebidos, tipo:(observação, data, IdPaciente, IdMédico)
        Consulta c = new Consulta(observacao, data, hora, idPaciente, idMedico); 
        // Chama o DAO para salvar no banco de dados
        dao.inserir(c);
    }
    // Método para listar todas as consultas.
    public ArrayList<Consulta> listar() {
        // Aqui vai listar e retornao resultado.
        return dao.listar();
    }
    // Método para agendar uma nova consulta.
    public void agendarConsulta(int idPaciente, int idMedico, LocalDate data, LocalTime hora, String observacao ){
        if (data == null || hora == null){
            // Exibe uma mensagem de erro para o usuário caso a data e a hara estiver vazia.
            JOptionPane.showMessageDialog(null, "Data e hora são obrigatorios!");
            return;// -> Encerra o método sem agendar a consulta.
        }
        // Cria um novo objeto Consulta e Preenche os dados recebidos.
        Consulta consulta = new Consulta();
        consulta.setIdPaciente(idPaciente);
        consulta.setIdMedico(idMedico);
        consulta.setData(data);
        consulta.setHora(hora);
        consulta.setObservacao(observacao);
        
        try{
           dao.inserir(consulta); // Insire a consulta no banco de dados através do DAO. 
           JOptionPane.showMessageDialog(null, "Consulta agendada com sucesso!");
        }catch (SQLException e){
            // Caso ocorra um erro no banco, exibe uma mensagem de erro. 
            JOptionPane.showMessageDialog(null," Erro ao agendar consulta: " + e.getMessage());
            
        }
    }
    
    // Método para atualizar uma consulta existente.
    public void atualizar(int idConsulta, String observacao, LocalDate data, LocalTime hora, int idPaciente, int idMedico) {
        // Vai Criar uma nova consulta com novos dados, incluindo o ID.
        Consulta c = new Consulta(idConsulta, observacao, data, hora, idPaciente, idMedico);
        // O DAO é chamado para atualizar no banco de dados.
        dao.atualizar(c);
    }
    // Método para remover uma consulta pelo ID.
    public void remover(int idConsulta) {
        // O DAO vai remover do banco de dados.
        dao.remover(idConsulta);
    }
}


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consultorio_fuboca.dao;
// Importações necessárias para o funcionamento da classe PacienteDAO.
import com.mycompany.consultorio_fuboca.Conexao_ao_banco.ConexaoMySQL;
import com.mycompany.consultorio_fuboca.modelo.Medico;
import com.mycompany.consultorio_fuboca.modelo.Paciente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * classe que cuida das operações de Paciente no banco de dados.
 * Essa classe faz inserções, buscar, atualizações e remover pacientes.
 */
public class PacienteDAO {
    // Método que insere um novo paciente no banco de dados.
    public void inserir(Paciente paciente) {
        String sql = "INSERT INTO paciente (nomePaciente, cpf, ddd, numTelefone, primeiroNomePaciente, nomeDoMeioPaciente, ultimoNomePaciente) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = ConexaoMySQL.conectar(); // -> Conecta ao banco
            PreparedStatement stmt = conn.prepareStatement(sql)) { // -> Prepara o SQL com segurança contra 
            // Preenche os dados do paciente no banco de dados
            stmt.setString(1, paciente.getNomePaciente());
            stmt.setString(2, paciente.getCpf());
            stmt.setString(3, paciente.getDdd());
            stmt.setString(4, paciente.getNumTelefone());
            stmt.setString(5, paciente.getPrimeiroNomePaciente());
            stmt.setString(6, paciente.getNomeDoMeioPaciente());
            stmt.setString(7, paciente.getUltimoNomePaciente());
            stmt.executeUpdate();// -> Executa o comando para inserir ao banco 
        } catch (SQLException e) {
            // Se der erro, mostra no console.
            e.printStackTrace();
        }
    }
    // Método que lista todos os paciente cadastradono banco de dados.
    public ArrayList<Paciente> listar() {
        ArrayList<Paciente> lista = new ArrayList<>();
        String sql = "SELECT * FROM paciente";
        try (Connection conn = ConexaoMySQL.conectar();// -> Conecta ao banco de dados.
             Statement stmt = conn.createStatement();// Cria uma consulta simples.
             ResultSet rs = stmt.executeQuery(sql)) {// -> Execulta a consulta
            // Pecorre cada linha do resultado.
            while (rs.next()) {
                Paciente p = new Paciente(
                    rs.getInt("idPaciente"),
                    rs.getString("nomePaciente"),
                    rs.getString("cpf"),
                    rs.getString("ddd"),
                    rs.getString("numTelefone"),
                    rs.getString("primeiroNomePaciente"),
                    rs.getString("nomeDoMeioPaciente"),
                    rs.getString("ultimoNomePaciente")
                );
                lista.add(p);// -> Adiciona o resultado na lista 
            }
        } catch (SQLException e) {
            e.printStackTrace();// -> Se der erro, mostra no console.
        }
        return lista;// -> Retorna a lista com todos os pacientes encontrados.
    }
    // Método que busca paciente pelo nome
    public ArrayList<Paciente> buscarPorNome(String nome) {
        ArrayList<Paciente> lista = new ArrayList<>();
        String sql = "SELECT * FROM paciente WHERE nomePaciente LIKE ?";

        try (Connection conn = ConexaoMySQL.conectar();// -> Conecta ao banco de dados
             PreparedStatement stmt = conn.prepareStatement(sql)) {//->  Prepara o banco de dados com segurança
            stmt.setString(1, "%" + nome + "%");//-> Mostra a busca com o nome parcial usado.
            ResultSet rs = stmt.executeQuery();
            // Precorre os resultados
            while (rs.next()) {
                // Cria um paciente com os dados da linha. 
                Paciente p = new Paciente(
                    rs.getInt("idPaciente"),
                    rs.getString("nomePaciente"),
                    rs.getString("cpf"),
                    rs.getString("ddd"),
                    rs.getString("numTelefone"),
                    rs.getString("primeiroNomePaciente"),
                    rs.getString("nomeDoMeioPaciente"),
                    rs.getString("ultimoNomePaciente")
                );
                lista.add(p);// -> Adiciona na lista. 
            }

        } catch (SQLException e) {
            // Se der erro, mostra no console.
            e.printStackTrace();
        }
        // Retorna a lista com os paciente encontrados no banco de dados.
        return lista;
    }
    // Método que atualiza os dados de um paciente no banco de dados.
    public void atualizar(Paciente paciente) {
        String sql = "UPDATE paciente SET nomePaciente = ?, cpf = ?, ddd = ?, numTelefone = ?, primeiroNomePaciente = ?, nomeDoMeioPaciente = ?, ultimoNomePaciente = ? WHERE idPaciente = ?";
        try (Connection conn = ConexaoMySQL.conectar();// -> conecta ao Banco de dados.
             PreparedStatement stmt = conn.prepareStatement(sql)) {// Prepara o banco de dados.
            // Preenche novos dados de paciente.
            stmt.setString(1, paciente.getNomePaciente());
            stmt.setString(2, paciente.getCpf());
            stmt.setString(3, paciente.getDdd());
            stmt.setString(4, paciente.getNumTelefone());
            stmt.setString(5, paciente.getPrimeiroNomePaciente());
            stmt.setString(6, paciente.getNomeDoMeioPaciente());
            stmt.setString(7, paciente.getUltimoNomePaciente());
            stmt.setInt(8, paciente.getIdPaciente());
            stmt.executeUpdate();// -> Execulta a atualização de paciente
        } catch (SQLException e) {
            // Se der erro, mostra no console.
            e.printStackTrace();
        }
    }
    // Método para remover um paciente pelo ID.
    public void remover(int idPaciente) {
        String sql = "DELETE FROM paciente WHERE idPaciente = ?";
        try (Connection conn = ConexaoMySQL.conectar();// Conecta ao banco de dados
             PreparedStatement stmt = conn.prepareStatement(sql)) {// Prepara o banco de dados 
            stmt.setInt(1, idPaciente);// -> Informa o ID do paciente que será excluido do banco de dados.
            stmt.executeUpdate();// -> Executa a exclusão.
        } catch (SQLException e) {
            // Se der erro, mostra no console.
            e.printStackTrace();
        }
    }
}
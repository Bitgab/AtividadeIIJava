/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consultorio_fuboca.controle;
// Importações necessárias para a classe ControleMédico.
import com.mycompany.consultorio_fuboca.dao.PacienteDAO;
import com.mycompany.consultorio_fuboca.modelo.Paciente;
import java.util.ArrayList;

/**
 *
 * Classe que faz o controle de Paciente.
 * Também faz ligação entre tela e o banco de dados.
 */
public class ControlePaciente {
    
    // Cria um objeto do DAO para acessar o banco de dados de Paciente.
    private PacienteDAO dao = new PacienteDAO();
    // Método para cadastrar novo Paciente.
    public void cadastrar(String nomePaciente, String cpf, String ddd, String numTelefone, String primeiroNome, String nomeDoMeio, String ultimoNome) {
        // Cria um novo Paciente com informações pedida (CPF, DDD, NumTelefone, Primeiro Nome, Nome do Meio, Ultimo Nome)
        Paciente p = new Paciente(nomePaciente, cpf, ddd, numTelefone, primeiroNome, nomeDoMeio, ultimoNome);
        //O DAO vai salvar as informações no banco de dados de Paciente.
        dao.inserir(p);
    }
    // Método para listar todos os Paciente 
    public ArrayList<Paciente> listar() {
        // retorna a lista que o DAO buscar no banco de dados do Paciente.
        return dao.listar();
    }
    // Método para atualizar Paciente já existente no banco do dados Paciente.
    public void atualizar(int idPaciente, String nomePaciente, String cpf, String ddd, String numTelefone, String primeiroNome, String nomeDoMeio, String ultimoNome) {
        // Cria um novo Paciente com  novos dados pedido (CPF, DDD, NumTelefone, Primeiro nome, Nome do Meio, ultimo nome). 
        Paciente p = new Paciente(idPaciente, nomePaciente, cpf, ddd, numTelefone, primeiroNome, nomeDoMeio, ultimoNome);
        // Mandar o DAO atualizar no banco de dados de Paciente.
        dao.atualizar(p);
    }
    // Método para remover Paciente pelo ID
    public void remover(int idPaciente) {
        // O DAO vai remover do banco de dados do Paciente
        dao.remover(idPaciente);
    }
    // Método para buscar Paciente pelo Nome.
    public ArrayList<Paciente> buscarPorNome(String nome) {
        // O DAO vai buscar o nome do Paciente no banco de dados do Paciente
        return dao.buscarPorNome(nome);
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.consultorio_fuboca;

/**
 *
 * @author facil
 */
public class Consultorio_Fuboca {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
